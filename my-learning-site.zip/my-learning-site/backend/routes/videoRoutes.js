const express = require('express');
const videoController = require('../controllers/videoController');
const router = express.Router();

router.post('/upload', videoController.uploadVideo);
router.get('/:id', videoController.getVideo);
router.put('/:id', videoController.updateVideo);
router.delete('/:id', videoController.deleteVideo);

module.exports = router;