document.addEventListener("DOMContentLoaded", () => {
  const videoContainer = document.getElementById("video-container");

  fetch('/api/videos')
    .then(response => response.json())
    .then(videos => {
      videos.forEach(video => {
        const videoElement = document.createElement('div');
        videoElement.classList.add('video-card');
        videoElement.innerHTML = `
          <h3>${video.title}</h3>
          <p>${video.description}</p>
        `;
        videoContainer.appendChild(videoElement);
      });
    })
    .catch(error => console.error('Error loading videos:', error));
});